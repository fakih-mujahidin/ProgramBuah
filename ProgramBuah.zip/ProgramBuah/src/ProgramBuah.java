// Tidak pakai package, biar langsung bisa dijalankan di NetBeans
import java.util.Scanner;

class Buah {
    // Atribut
    String nama;
    String rasa;

    // Method untuk menampilkan informasi buah
    void tampilkanInfo() {
        System.out.println("\nNama Buah: " + nama);
        System.out.println("Rasa     : " + rasa);
        System.out.println("------------------------");
    }

    // Method untuk menampilkan aksi
    void dimakan() {
        System.out.println("Buah " + nama + " sedang dimakan");
        System.out.println();
    }
}

public class ProgramBuah {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Membuat objek dari class Buah
        Buah buah = new Buah();

        // Input data dari pengguna
        System.out.print("Masukkan nama buah: ");
        buah.nama = input.nextLine();

        System.out.print("Masukkan rasa buah: ");
        buah.rasa = input.nextLine();

        // Menampilkan hasil menggunakan method
        buah.tampilkanInfo();
        buah.dimakan();

        input.close();
    }
}

